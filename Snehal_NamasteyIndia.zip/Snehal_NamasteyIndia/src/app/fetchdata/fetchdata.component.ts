import { Component } from '@angular/core';
import {ActivatedRoute}from "@angular/router";
@Component({
  selector: 'app-fetchdata',
  templateUrl: './fetchdata.component.html',
  styleUrls: ['./fetchdata.component.css']
})
export class FetchdataComponent {
  public stateid:any;
  public statename:any;
  public statepopulation:any;
  public stategdp:any;
  public statelang:any;
  public stateattrac:any;
  public stateimg:any;

constructor(private route:ActivatedRoute){
   
}

ngOnInit()
    {
      
      
      let id=this.route.snapshot.paramMap.get('stateid');
      this.stateid=id;

      let name=this.route.snapshot.paramMap.get('statename');
      this.statename=name;

      let population=this.route.snapshot.paramMap.get('statepopulation');
      this.statepopulation=population;

      this.statepopulation=Math.round(this.statepopulation/100000);

      let GDP=this.route.snapshot.paramMap.get('stategdp');
      this.stategdp=GDP;

      let language=this.route.snapshot.paramMap.get('statelang');
      this.statelang=language;


      let attraction=this.route.snapshot.paramMap.get('stateattrac');
      this.stateattrac=attraction;

      let image=this.route.snapshot.paramMap.get('stateimg');
      this.stateimg=image;

      // console.log(id+name);
      
    }
}