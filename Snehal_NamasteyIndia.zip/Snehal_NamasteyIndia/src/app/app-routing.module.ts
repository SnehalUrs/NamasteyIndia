import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { MyindiaComponent } from './myindia/myindia.component';
import { StatesComponent } from './states/states.component';
import{FetchdataComponent} from './fetchdata/fetchdata.component';

import { statemodel } from './states/state.model';

const routes: Routes = [
{path:'',redirectTo:'/home',pathMatch:'full'},
{path:'home',component:HomepageComponent},
{path:'Info',component:MyindiaComponent},
{path:'state',component:StatesComponent},
{path:'state/:stateid/:statename/:statepopulation/:stategdp/:statelang/:stateattrac/:stateimg',component: FetchdataComponent}

];
 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
