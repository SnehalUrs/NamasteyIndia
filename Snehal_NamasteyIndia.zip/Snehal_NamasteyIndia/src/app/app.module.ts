import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{FormsModule,ReactiveFormsModule} from '@angular/forms';
import{HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { MyindiaComponent } from './myindia/myindia.component';
import { StatesComponent } from './states/states.component';
import { FetchdataComponent } from './fetchdata/fetchdata.component';

@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    MyindiaComponent,
    StatesComponent,
    FetchdataComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
