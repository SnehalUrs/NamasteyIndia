import { Component } from '@angular/core';
import { ApiService } from '../shared/api.service';
import { statemodel} from './state.model';
import{FormBuilder,FormGroup} from '@angular/forms';
import{Router} from "@angular/router";

@Component({
  selector: 'app-states',
  templateUrl: './states.component.html',
  styleUrls: ['./states.component.css']
})
export class StatesComponent {
  formValue !: FormGroup;
  stateModeloBJ: statemodel = new statemodel();
  stateData: any;
  
  showAdd!:boolean;

  constructor(private formBuilder: FormBuilder, private api: ApiService, private router:Router) {  }

  ngOnInit() {
    this.formValue = this.formBuilder.group({
      name: [''],
      population: [''],
      GDP: [''],
      language: [''],
      attraction: [''],
      Image:['']
    });
    this.getAllStates();
  }

  getAllStates() {
    this.api.getStates().subscribe(
      res => {
        this.stateData = res;
      }
    )
  }
fetchState(state:any)
{
  console.log(state);
  

  this.router.navigate(["/state",state.id,state.name,state.population,state.GDP,state.language,state.attraction,state.img]);
}


deleteState(st: any) {
  this.api.deleteState(st.id).subscribe(
    res => {
      alert("State Deleted");
      this.getAllStates();
    }

  )
}

clickAddEmployee()
  {
    this.formValue.reset();
    this.showAdd=true;
    
  }
  postStateDetails() {
    this.stateModeloBJ.name = this.formValue.value.name;
    this.stateModeloBJ.population = this.formValue.value.population;
    this.stateModeloBJ.GDP = this.formValue.value.GDP;
    this.stateModeloBJ.language = this.formValue.value.language;
    this.stateModeloBJ.attraction = this.formValue.value.attraction;
    this.stateModeloBJ.image= this.formValue.value.image;


    this.api.postState(this.stateModeloBJ).subscribe(
      res => {
        console.log(res);
        alert("State Added Successfully!!!");
        let close = document.getElementById("cancel");
        close?.click();
        this.formValue.reset();
        this.getAllStates();
      },
      err => {
        alert("somting went wrong");
      }
    )

  }



}
