export class statemodel{
    id:number=0;
    name:string='';
    population: number=0;
    GDP: number=0;
    language:string='';
    attraction:string='';
    image:string='';

}